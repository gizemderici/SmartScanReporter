import os
import re
import subprocess
import xml.etree.ElementTree as ET
from ipaddress import ip_network


BASE_DIR = os.path.dirname(__file__)
XML_DOSYASI = os.path.join(BASE_DIR, "scan_results", "output.xml")
DISCOVERY_XML_DOSYASI = os.path.join(BASE_DIR, "scan_results", "discovery_output.xml")
SCAN_PROFILES = {
    "quick": {
        "label": "Hizli Tarama",
        "args": [],
    },
    "syn": {
        "label": "SYN Tarama",
        "args": ["-sS"],
    },
    "udp": {
        "label": "UDP Tarama",
        "args": ["-sU"],
    },
    "detailed": {
        "label": "Detayli Tarama",
        "args": ["-sV", "-O"],
    },
    "ping": {
        "label": "Ping Scan",
        "args": ["-sn"],
    },
    "vuln": {
        "label": "Zafiyet Taramasi",
        "args": ["-sV", "--script", "vuln"],
    },
}
NSE_SCRIPT_OPTIONS = {
    "safe": {
        "label": "Guvenli Scriptler",
        "scripts": ["default"],
    },
    "http": {
        "label": "HTTP Bilgi Toplama",
        "scripts": ["http-title", "http-headers"],
    },
    "smb": {
        "label": "SMB Kontrol",
        "scripts": ["smb-protocols", "smb-security-mode"],
    },
    "cve": {
        "label": "CVE Kontrol",
        "scripts": ["vuln"],
    },
}
PORT_SCOPE_OPTIONS = {
    "default": "Varsayilan Portlar",
    "custom": "Ozel Port Araligi",
    "all": "Tum Portlar",
}


def get_scan_profile(scan_type: str):
    return SCAN_PROFILES.get(scan_type, SCAN_PROFILES["detailed"])


def get_scan_label(scan_type: str) -> str:
    return get_scan_profile(scan_type)["label"]


def normalize_port_scope(port_scope):
    scope = (port_scope or "default").strip().lower()
    return scope if scope in PORT_SCOPE_OPTIONS else "default"


def normalize_port_spec(port_scope, port_spec=""):
    scope = normalize_port_scope(port_scope)
    if scope != "custom":
        return ""

    value = "".join((port_spec or "").strip().split())
    if not value:
        raise ValueError("Ozel port araligi secildiginde port bilgisi girilmelidir.")

    for part in value.split(","):
        if not re.fullmatch(r"\d+(-\d+)?", part or ""):
            raise ValueError("Port formati gecersiz. Ornek: 22,80,443 veya 1-1000")
        if "-" in part:
            start_text, end_text = part.split("-", 1)
            start_port = int(start_text)
            end_port = int(end_text)
            if start_port < 1 or end_port > 65535 or start_port > end_port:
                raise ValueError("Port araligi 1-65535 arasynda olmali ve baslangic bitisten buyuk olmamalidir.")
        else:
            port = int(part)
            if port < 1 or port > 65535:
                raise ValueError("Port numaralari 1 ile 65535 arasynda olmalidir.")

    return value


def get_port_label(port_scope, port_spec=""):
    scope = normalize_port_scope(port_scope)
    if scope == "all":
        return "Tum Portlar"
    if scope == "custom":
        return f"Portlar: {normalize_port_spec(scope, port_spec)}"
    return "Varsayilan Portlar"


def normalize_nse_scripts(selected_scripts=None):
    normalized = []
    for key in selected_scripts or []:
        script_key = (key or "").strip().lower()
        if script_key in NSE_SCRIPT_OPTIONS and script_key not in normalized:
            normalized.append(script_key)
    return normalized


def get_nse_script_labels(selected_scripts=None):
    normalized = normalize_nse_scripts(selected_scripts)
    return [NSE_SCRIPT_OPTIONS[key]["label"] for key in normalized]


def build_nse_args(selected_scripts=None):
    normalized = normalize_nse_scripts(selected_scripts)
    script_names = []
    for key in normalized:
        for script_name in NSE_SCRIPT_OPTIONS[key]["scripts"]:
            if script_name not in script_names:
                script_names.append(script_name)
    if not script_names:
        return []
    return ["--script", ",".join(script_names)]


def build_port_args(port_scope="default", port_spec=""):
    scope = normalize_port_scope(port_scope)
    if scope == "all":
        return ["-p-"]
    if scope == "custom":
        return ["-p", normalize_port_spec(scope, port_spec)]
    return []


def is_subnet_target(target) -> bool:
    value = (target or "").strip() if isinstance(target, str) else ""
    if not value or "/" not in value:
        return False
    try:
        ip_network(value, strict=False)
    except ValueError:
        return False
    return True


def normalize_targets(target):
    if isinstance(target, (list, tuple, set)):
        return [str(item).strip() for item in target if str(item).strip()]
    value = str(target or "").strip()
    return [value] if value else []


def build_nmap_command(target, scan_type: str = "detailed", selected_scripts=None, port_scope="default", port_spec=""):
    profile = get_scan_profile(scan_type)
    nse_args = build_nse_args(selected_scripts)
    port_args = build_port_args(port_scope, port_spec)
    targets = normalize_targets(target)

    # Buyuk aglar ve coklu host taramalari icin daha stabil ayarlar
    host_group = "32" if len(targets) > 8 or any(is_subnet_target(item) for item in targets) else "8"
    host_timeout = "45s" if len(targets) > 1 else "90s"
    performance_args = [
        "--max-hostgroup", host_group,
        "--host-timeout", host_timeout,
        "--max-parallelism", "8",
        "--max-retries", "1",
        "--min-rate", "50",
    ]

    return ["nmap", *profile["args"], *port_args, *nse_args, *performance_args, "-oX", XML_DOSYASI, *targets]


def build_discovery_command(target: str):
    return ["nmap", "-sn", "-oX", DISCOVERY_XML_DOSYASI, target]


def start_nmap_scan(target, scan_type: str = "detailed", selected_scripts=None, port_scope="default", port_spec=""):
    os.makedirs(os.path.dirname(XML_DOSYASI), exist_ok=True)
    if os.path.exists(XML_DOSYASI):
        os.remove(XML_DOSYASI)
    command = build_nmap_command(target, scan_type, selected_scripts, port_scope, port_spec)
    return subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def run_nmap_scan(target: str, scan_type: str = "detailed", selected_scripts=None, port_scope="default", port_spec=""):
    process = start_nmap_scan(target, scan_type, selected_scripts, port_scope, port_spec)
    _, stderr = process.communicate()
    return process.returncode == 0, stderr


def run_ping_discovery(target: str):
    os.makedirs(os.path.dirname(DISCOVERY_XML_DOSYASI), exist_ok=True)
    command = build_discovery_command(target)
    result = subprocess.run(command, capture_output=True, text=True)
    return result.returncode == 0, result.stderr


def start_ping_discovery(target: str):
    os.makedirs(os.path.dirname(DISCOVERY_XML_DOSYASI), exist_ok=True)
    if os.path.exists(DISCOVERY_XML_DOSYASI):
        os.remove(DISCOVERY_XML_DOSYASI)
    command = build_discovery_command(target)
    return subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def parse_discovery_results(xml_path: str = DISCOVERY_XML_DOSYASI):
    try:
        root = ET.parse(xml_path).getroot()
    except (ET.ParseError, OSError) as error:
        raise ValueError(f"Discovery XML okunamadi: {error}") from error

    devices = []
    for host in root.findall("host"):
        status = host.find("status")
        if status is None or status.get("state") != "up":
            continue

        ip_address = "Bilinmiyor"
        mac_address = None
        vendor = None

        for address in host.findall("address"):
            addr_type = address.get("addrtype")
            if addr_type == "ipv4":
                ip_address = address.get("addr", "Bilinmiyor")
            elif addr_type == "mac":
                mac_address = address.get("addr")
                vendor = address.get("vendor")

        hostnames = host.find("hostnames")
        hostname = None
        if hostnames is not None:
            hostname_node = hostnames.find("hostname")
            if hostname_node is not None:
                hostname = hostname_node.get("name")

        devices.append(
            {
                "ip": ip_address,
                "hostname": hostname or "Bilinmiyor",
                "mac": mac_address or "Bilinmiyor",
                "vendor": vendor or "Bilinmiyor",
            }
        )

    return {
        "target": target_from_xml(root),
        "device_count": len(devices),
        "devices": devices,
    }


def target_from_xml(root):
    runstats = root.find("runstats")
    if runstats is None:
        return "Bilinmiyor"
    finished = runstats.find("finished")
    if finished is None:
        return "Bilinmiyor"
    return finished.get("summary", "Bilinmiyor")
