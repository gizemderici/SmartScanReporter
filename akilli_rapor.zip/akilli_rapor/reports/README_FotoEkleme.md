# Akıllı Ağ Tarama Raporlama Sistemi - Fotoğraf Ekleme Rehberi

## Raporunuza Fotoğraf Eklemek İçin

### 1. Statik Dosyalar Klasörü
Proje içinde `akilli_rapor/static/` klasörü bulunmaktadır. Bu klasöre aşağıdaki fotoğrafları ekleyebilirsiniz:

### 2. Önerilen Fotoğraflar
- `logo.png` - Şirket veya proje logosu (header'da kullanılır)
- `security_icons.png` - Güvenlik simgeleri
- `network_diagram.png` - Özel ağ diyagramları
- `team_photos/` klasörü - Takım fotoğrafları

### 3. HTML'de Fotoğraf Kullanımı
Rapor HTML'inde fotoğrafları şu şekilde kullanabilirsiniz:

```html
<img src="/static/logo.png" alt="Şirket Logosu" style="max-width: 200px;">
```

### 4. Örnek Eklemeler
- Header'a logo ekleme
- Güvenlik bölümlerine ikonlar ekleme
- Takım bilgilerini fotoğraflarla zenginleştirme

### 5. Fotoğraf Önerileri
- Yüksek çözünürlükte PNG veya JPG formatı
- Şeffaf arka plan için PNG
- Dosya boyutunu optimize edin (max 500KB)
- Güvenlik temalı görseller kullanın

Bu şekilde raporunuz daha profesyonel ve görsel olarak zengin hale gelecektir.</content>
<parameter name="filePath">c:\SmartScanReporter\akilli_rapor\README_FotoEkleme.md