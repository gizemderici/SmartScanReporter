import os
import threading
import time
import uuid
import warnings
from ipaddress import ip_network

os.environ["MPLBACKEND"] = "Agg"

# Matplotlib uyarilarini kapat
import matplotlib

matplotlib.use("Agg", force=True)
matplotlib.rcParams["figure.max_open_warning"] = 0
warnings.filterwarnings("ignore", message=".*Matplotlib.*")
warnings.filterwarnings("ignore", message=".*GUI.*")

from flask import Flask, Response, jsonify, render_template, request, send_file

from analyzer import parse_results
from chart_generator import generate_discovery_topology, generate_network_topology, generate_os_chart, generate_risk_chart
from cve_lookup import enrich_reports_with_online_cves
from env_loader import load_env_file
from history import get_recent_scan_history, get_scan_history_detail, init_history_db, record_scan_history
from history_tracker import record_and_compare_discovery, record_and_compare_scan
from reporter import (
    HTML_RAPOR_DOSYASI,
    PDF_RAPOR_DOSYASI,
    TXT_RAPOR_DOSYASI,
    build_printable_report_html,
    can_generate_pdf,
    generate_reports,
)
from scenario_generator import generate_attack_scenarios
from scanner import (
    NSE_SCRIPT_OPTIONS,
    PORT_SCOPE_OPTIONS,
    SCAN_PROFILES,
    XML_DOSYASI,
    get_nse_script_labels,
    is_subnet_target,
    get_port_label,
    get_scan_label,
    normalize_nse_scripts,
    normalize_port_scope,
    normalize_port_spec,
    parse_discovery_results,
    run_ping_discovery,
    start_nmap_scan,
    start_ping_discovery,
)
from team_advisor import BLUE_TEAM, RED_TEAM, apply_team_mode_analysis


load_env_file()

app = Flask(__name__)
init_history_db()
SCAN_JOBS = {}
SCAN_JOBS_LOCK = threading.Lock()


def _append_job_log(job, level, message):
    logs = job.setdefault("logs", [])
    logs.append({"level": level, "message": message})
    if len(logs) > 20:
        del logs[:-20]


def _attach_udp_summary(network_summary, host_reports):
    udp_services = []
    udp_host_ips = set()

    for host in host_reports:
        for port in host.get("open_ports_data", []):
            if (port.get("protocol") or "").lower() != "udp":
                continue
            udp_host_ips.add(host.get("ip"))
            udp_services.append(
                {
                    "ip": host.get("ip", "Bilinmiyor"),
                    "port": port.get("port"),
                    "service": port.get("service", "Bilinmiyor"),
                    "risk": port.get("risk", "Bilinmiyor"),
                }
            )

    network_summary["udp_service_count"] = len(udp_services)
    network_summary["udp_host_count"] = len(udp_host_ips)
    network_summary["udp_services"] = udp_services[:8]


def _attach_nse_summary(network_summary, host_reports):
    findings = []
    host_ips = set()

    for host in host_reports:
        for port in host.get("open_ports_data", []):
            for finding in port.get("nse_findings", []):
                host_ips.add(host.get("ip"))
                findings.append(
                    {
                        "ip": host.get("ip", "Bilinmiyor"),
                        "port": port.get("port"),
                        "protocol": port.get("protocol", "tcp"),
                        "service": port.get("service", "Bilinmiyor"),
                        "script_id": finding.get("id", "Bilinmeyen script"),
                        "summary": finding.get("summary", "Script bulgusu bulundu"),
                    }
                )

    network_summary["nse_finding_count"] = len(findings)
    network_summary["nse_host_count"] = len(host_ips)
    network_summary["nse_findings"] = findings[:10]


def _create_job(target, team_mode, scan_type, nse_scripts, port_scope, port_spec):
    job_id = uuid.uuid4().hex
    nse_script_labels = get_nse_script_labels(nse_scripts)
    port_label = get_port_label(port_scope, port_spec)
    job = {
        "id": job_id,
        "target": target,
        "team_mode": team_mode,
        "scan_type": scan_type,
        "scan_label": get_scan_label(scan_type),
        "port_scope": port_scope,
        "port_spec": port_spec,
        "port_label": port_label,
        "nse_scripts": nse_scripts,
        "nse_script_labels": nse_script_labels,
        "status": "queued",
        "progress": 0,
        "message": "Tarama sirasina alindi.",
        "error": None,
        "result": None,
        "cancel_requested": False,
        "process": None,
        "current_step": "queued",
        "logs": [],
    }
    _append_job_log(job, "info", f"Tarama sirasina alindi. Mod: {get_scan_label(scan_type)}")
    _append_job_log(job, "info", f"Port kapsami: {port_label}")
    if nse_script_labels:
        _append_job_log(job, "info", f"NSE script secimleri: {', '.join(nse_script_labels)}")
    with SCAN_JOBS_LOCK:
        SCAN_JOBS[job_id] = job
    return job


def _update_job(job_id, **fields):
    with SCAN_JOBS_LOCK:
        job = SCAN_JOBS.get(job_id)
        if job is not None:
            log_message = fields.pop("log_message", None)
            log_level = fields.pop("log_level", "info")
            job.update(fields)
            if log_message:
                _append_job_log(job, log_level, log_message)


def _get_job(job_id):
    with SCAN_JOBS_LOCK:
        job = SCAN_JOBS.get(job_id)
        if job is None:
            return None
        return dict(job)


def _mark_job_canceled(job_id, progress=None, message="Tarama iptal edildi."):
    fields = {
        "status": "canceled",
        "message": message,
        "error": None,
        "process": None,
        "log_message": message,
        "log_level": "warn",
    }
    if progress is not None:
        fields["progress"] = progress
    _update_job(job_id, **fields)


def _job_cancel_requested(job_id):
    job = _get_job(job_id)
    return bool(job and job.get("cancel_requested"))


def _stop_job_process(job_id):
    job = _get_job(job_id)
    process = None if job is None else job.get("process")
    if process is None:
        return

    try:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except Exception:
                process.kill()
    except Exception:
        pass
    finally:
        _update_job(job_id, process=None)


def _check_for_cancel(job_id, progress, message):
    if _job_cancel_requested(job_id):
        _mark_job_canceled(job_id, progress=progress, message=message)
        return True
    return False


def _estimate_target_size(target):
    if isinstance(target, (list, tuple, set)):
        return max(1, len(target))
    value = (target or "").strip()
    if not value:
        return 1
    try:
        if "/" in value:
            return max(1, int(ip_network(value, strict=False).num_addresses))
    except ValueError:
        return 1
    return 1


def _run_discovery_phase(job_id, target):
    _update_job(
        job_id,
        progress=8,
        message="Subnet icindeki canli hostlar kesfediliyor.",
        current_step="nmap",
        log_message="Subnet hedefi algilandi, once canli host kesfi baslatildi.",
    )
    process = start_ping_discovery(target)
    _update_job(job_id, process=process)

    discovery_started_at = time.time()
    last_live_update = 0
    max_discovery_seconds = 90

    while process.poll() is None:
        if _job_cancel_requested(job_id):
            _stop_job_process(job_id)
            _mark_job_canceled(job_id, progress=10, message="Host kesfi kullanici tarafindan iptal edildi.")
            return None

        now = time.time()
        if now - last_live_update >= 2:
            ratio = min((now - discovery_started_at) / max_discovery_seconds, 0.95)
            progress = min(18, 8 + int(round(ratio * 10)))
            _update_job(
                job_id,
                progress=progress,
                message="Subnet icindeki canli hostlar kesfediliyor.",
                current_step="nmap",
            )
            last_live_update = now

        if now - discovery_started_at > max_discovery_seconds:
            try:
                process.terminate()
                process.wait(timeout=3)
            except Exception:
                try:
                    process.kill()
                except Exception:
                    pass
            break

        threading.Event().wait(0.5)

    try:
        _, stderr = process.communicate(timeout=2)
    except Exception:
        stderr = ""
    _update_job(job_id, process=None)

    if process.returncode != 0:
        _update_job(
            job_id,
            status="failed",
            progress=100,
            error=f"Host kesfi hatasi: {stderr}",
            message="Subnet host kesfi tamamlanamadi.",
            log_message=f"Host kesfi hatasi alindi: {str(stderr).strip() or 'Bilinmeyen hata'}",
            log_level="error",
        )
        return None

    discovery_result = parse_discovery_results()
    active_hosts = [device.get("ip") for device in discovery_result.get("devices", []) if device.get("ip") and device.get("ip") != "Bilinmiyor"]

    if not active_hosts:
        _update_job(
            job_id,
            status="failed",
            progress=100,
            error="Subnet icinde erisilebilir host bulunamadi.",
            message="Canli host bulunamadigi icin detay tarama baslatilamadi.",
            log_message="Host kesfi tamamlandi ancak canli host bulunamadi.",
            log_level="warn",
        )
        return None

    _update_job(
        job_id,
        progress=20,
        message=f"{len(active_hosts)} aktif host bulundu. Detay tarama baslatiliyor.",
        current_step="nmap",
        log_message=f"Host kesfi tamamlandi, {len(active_hosts)} aktif host bulundu.",
    )
    return active_hosts


def _build_nmap_live_progress(target, scan_started_at, max_scan_seconds):
    elapsed_seconds = max(0, time.time() - scan_started_at)
    time_ratio = min(elapsed_seconds / max(max_scan_seconds, 1), 0.98)
    discovered_hosts = 0
    progress_floor = 20 if isinstance(target, (list, tuple, set)) else 8

    try:
        if os.path.exists(XML_DOSYASI):
            with open(XML_DOSYASI, "r", encoding="utf-8", errors="ignore") as handle:
                xml_text = handle.read()
            discovered_hosts = max(xml_text.count("<hosthint>"), xml_text.count("<host>"))
    except OSError:
        discovered_hosts = 0

    target_size = _estimate_target_size(target)
    discovery_ratio = 0.0
    if target_size > 1 and discovered_hosts > 0:
        discovery_ratio = min(discovered_hosts / target_size, 1.0)
    elif discovered_hosts > 0:
        discovery_ratio = 0.35

    progress_ratio = max(time_ratio * 0.85, discovery_ratio)
    live_progress = min(28, progress_floor + int(round(progress_ratio * (28 - progress_floor))))

    if discovered_hosts > 0:
        live_message = (
            f"Host kesfi ve port tarama suruyor. "
            f"Su ana kadar {discovered_hosts} host ipucu bulundu."
        )
    else:
        live_message = "Host kesfi ve port tarama suruyor. Nmap ara sonuclari bekleniyor."

    return live_progress, live_message


def _run_scan_job(job_id, target, team_mode, scan_type, nse_scripts, port_scope, port_spec):
    try:
        nse_script_labels = get_nse_script_labels(nse_scripts)
        port_label = get_port_label(port_scope, port_spec)
        subnet_target = is_subnet_target(target)
        scan_message = f"{get_scan_label(scan_type)} baslatiliyor."
        scan_message += f" {port_label}."
        if nse_script_labels:
            scan_message += f" NSE: {', '.join(nse_script_labels)}."
        if subnet_target and scan_type != "ping":
            scan_message += " Subnet hedefi oldugu icin once canli host kesfi yapilacak."
        _update_job(
            job_id,
            status="running",
            progress=8,
            message=scan_message,
            current_step="nmap",
            log_message=f"Host kesfi ve port tarama baslatildi. Profil: {get_scan_label(scan_type)} | {port_label}"
            + (f" | NSE: {', '.join(nse_script_labels)}" if nse_script_labels else ""),
        )
        scan_target = target
        if subnet_target and scan_type != "ping":
            scan_target = _run_discovery_phase(job_id, target)
            if scan_target is None:
                return

        process = start_nmap_scan(scan_target, scan_type, nse_scripts, port_scope, port_spec)
        _update_job(job_id, process=process)

        target_size = _estimate_target_size(scan_target)
        if target_size > 1:
            _max_scan_seconds = min(420, 120 + (target_size * 25))
        else:
            _max_scan_seconds = 180
        _scan_start = time.time()
        _timed_out = False
        _last_live_update = 0

        while process.poll() is None:
            if _job_cancel_requested(job_id):
                _stop_job_process(job_id)
                _mark_job_canceled(job_id, progress=12, message="Tarama kullanici tarafindan iptal edildi.")
                return
            now = time.time()
            if now - _last_live_update >= 2:
                live_progress, live_message = _build_nmap_live_progress(scan_target, _scan_start, _max_scan_seconds)
                _update_job(job_id, progress=live_progress, message=live_message, current_step="nmap")
                _last_live_update = now
            if now - _scan_start > _max_scan_seconds:
                _timed_out = True
                _update_job(job_id, log_message=f"Tarama suresi asimi ({_max_scan_seconds}sn), mevcut sonuclar isleniyor.", log_level="warn")
                try:
                    process.terminate()
                    process.wait(timeout=3)
                except Exception:
                    try:
                        process.kill()
                    except Exception:
                        pass
                break
            threading.Event().wait(0.5)

        try:
            _, stderr = process.communicate(timeout=2)
        except Exception:
            stderr = b""
        _update_job(job_id, process=None)

        if not _timed_out and process.returncode != 0:
            _update_job(
                job_id,
                status="failed",
                progress=100,
                error=f"Nmap hatasi: {stderr}",
                message="Tarama basarisiz oldu.",
                log_message=f"Nmap hatasi alindi: {stderr.strip() or 'Bilinmeyen hata'}",
                log_level="error",
            )
            return

        if _check_for_cancel(job_id, 30, "Tarama XML cozumleme oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=30,
            message="Host kesfi tamamlandi, port tarama sonuclari isleniyor.",
            current_step="parse",
            log_message="Host kesfi ve port tarama tamamlandi, sonuc isleme basladi.",
        )
        network_summary, host_reports = parse_results()

        if _check_for_cancel(job_id, 48, "Tarama CVE zenginlestirme oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=48,
            message="Versiyon ve zafiyet analizi yapiliyor.",
            current_step="cve",
            log_message="Versiyon ve zafiyet analizi asamasina gecildi.",
        )
        enrich_reports_with_online_cves(network_summary, host_reports)
        _attach_udp_summary(network_summary, host_reports)
        _attach_nse_summary(network_summary, host_reports)

        if _check_for_cancel(job_id, 62, "Tarama senaryo uretimi oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=62,
            message="Bulgular yorumlaniyor ve saldiri senaryolari hazirlaniyor.",
            current_step="scenario",
            log_message="Bulgular yorumlanmaya baslandi, senaryo uretimi suruyor.",
        )
        generate_attack_scenarios(network_summary, host_reports)

        if _check_for_cancel(job_id, 72, "Tarama takim modu analizi oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=72,
            message="Red Team / Blue Team degerlendirmesi yapiliyor.",
            current_step="team",
            log_message="Takim modu degerlendirmesi basladi.",
        )
        apply_team_mode_analysis(network_summary, host_reports)

        if _check_for_cancel(job_id, 80, "Tarama gecmis karsilastirma oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=80,
            message="Gecmis taramalarla karsilastirma yapiliyor.",
            current_step="history",
            log_message="Gecmis tarama karsilastirmasi basladi.",
        )
        comparison = record_and_compare_scan(target, network_summary, host_reports)

        if _check_for_cancel(job_id, 88, "Tarama grafik olusturma oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=88,
            message="Grafikler ve topoloji gorselleri hazirlaniyor.",
            current_step="charts",
            log_message="Grafik ve topoloji hazirlama basladi.",
        )
        generate_risk_chart(network_summary)
        generate_os_chart(network_summary)
        generate_network_topology(target, network_summary)

        if _check_for_cancel(job_id, 95, "Tarama rapor olusturma oncesi iptal edildi."):
            return
        _update_job(
            job_id,
            progress=95,
            message="Raporlama tamamlanmak uzere, ciktilar olusturuluyor.",
            current_step="reports",
            log_message="Rapor olusturma asamasi basladi.",
        )
        generate_reports(network_summary, host_reports, comparison, mode=team_mode)
        record_scan_history(target, scan_type, get_scan_label(scan_type), team_mode, network_summary, host_reports)

        _update_job(
            job_id,
            status="completed",
            progress=100,
            message="Tarama tamamlandi. Sonuclar ve raporlar hazir.",
            current_step="completed",
            result={
                "network_summary": network_summary,
                "host_reports": host_reports,
                "comparison": comparison,
            },
            cancel_requested=False,
            log_message="Tarama ve raporlama basariyla tamamlandi.",
        )
    except ValueError as parse_error:
        _update_job(
            job_id,
            status="failed",
            progress=100,
            error=str(parse_error),
            message="Analiz tamamlanamadi.",
            process=None,
            log_message=f"Analiz hatasi: {parse_error}",
            log_level="error",
        )
    except Exception as unexpected_error:
        _update_job(
            job_id,
            status="failed",
            progress=100,
            error=f"Beklenmeyen hata: {unexpected_error}",
            message="Tarama beklenmeyen bir hata ile sonlandi.",
            process=None,
            log_message=f"Beklenmeyen hata: {unexpected_error}",
            log_level="error",
        )


@app.route("/", methods=["GET"])
def index():
    network_summary = None
    host_reports = None
    comparison = None
    error = None
    target = request.args.get("target", "").strip()
    team_mode = request.args.get("team_mode", RED_TEAM).strip().lower()
    scan_type = request.args.get("scan_type", "detailed").strip().lower()
    port_scope = normalize_port_scope(request.args.get("port_scope", "default"))
    port_spec = ""
    auto_start = request.args.get("autostart", "").strip().lower() in {"1", "true", "yes"}
    selected_nse_scripts = []
    recent_history = get_recent_scan_history()

    if team_mode not in {RED_TEAM, BLUE_TEAM}:
        team_mode = RED_TEAM
    if scan_type not in SCAN_PROFILES:
        scan_type = "detailed"

    job_id = request.args.get("job", "").strip()
    if job_id:
        job = _get_job(job_id)
        if job is None:
            error = "Tarama oturumu bulunamadi."
        else:
            target = job.get("target", "")
            team_mode = job.get("team_mode", RED_TEAM)
            scan_type = job.get("scan_type", "detailed")
            port_scope = normalize_port_scope(job.get("port_scope", "default"))
            port_spec = job.get("port_spec", "")
            selected_nse_scripts = job.get("nse_scripts", [])
            if job.get("status") == "completed" and job.get("result"):
                result = job["result"]
                network_summary = result.get("network_summary")
                host_reports = result.get("host_reports")
                comparison = result.get("comparison")
            elif job.get("status") == "canceled":
                error = job.get("message") or "Tarama iptal edildi."
            elif job.get("status") == "failed":
                error = job.get("error") or "Tarama tamamlanamadi."

    return render_template(
        "index.html",
        network_summary=network_summary,
        host_reports=host_reports,
        comparison=comparison,
        error=error,
        target=target,
        team_mode=team_mode,
        scan_type=scan_type,
        port_scope=port_scope,
        port_spec=port_spec,
        scan_profiles=SCAN_PROFILES,
        port_scope_options=PORT_SCOPE_OPTIONS,
        nse_script_options=NSE_SCRIPT_OPTIONS,
        selected_nse_scripts=selected_nse_scripts,
        recent_history=recent_history,
        auto_start=auto_start,
    )


@app.route("/discovery", methods=["GET", "POST"])
def discovery():
    target = ""
    discovery_result = None
    discovery_comparison = None
    error = None

    if request.method == "POST":
        target = request.form.get("target", "").strip()
        if not target:
            error = "Lutfen bir subnet girin. Ornek: 192.168.1.0/24"
        else:
            success, stderr = run_ping_discovery(target)
            if not success:
                error = f"Nmap hatasi: {stderr}"
            else:
                try:
                    discovery_result = parse_discovery_results()
                    discovery_result["target"] = target
                    discovery_comparison = record_and_compare_discovery(target, discovery_result)
                    new_device_ips = {device["ip"] for device in discovery_comparison.get("new_devices", [])}
                    for device in discovery_result.get("devices", []):
                        device["is_new"] = device.get("ip") in new_device_ips
                    generate_discovery_topology(target, discovery_result.get("devices", []))
                except ValueError as parse_error:
                    error = str(parse_error)

    return render_template(
        "discovery.html",
        target=target,
        discovery_result=discovery_result,
        discovery_comparison=discovery_comparison,
        error=error,
    )


@app.route("/history/<int:history_id>")
def history_detail(history_id):
    history_item = get_scan_history_detail(history_id)
    if history_item is None:
        return Response("Tarama gecmisi bulunamadi.", status=404, mimetype="text/plain; charset=utf-8")

    return render_template("history_detail.html", history_item=history_item)


@app.route("/scan/start", methods=["POST"])
def start_scan():
    target = request.form.get("target", "").strip()
    team_mode = request.form.get("team_mode", RED_TEAM).strip().lower()
    scan_type = request.form.get("scan_type", "detailed").strip().lower()
    port_scope = normalize_port_scope(request.form.get("port_scope", "default"))
    nse_scripts = normalize_nse_scripts(request.form.getlist("nse_scripts"))
    if team_mode not in {RED_TEAM, BLUE_TEAM}:
        team_mode = RED_TEAM
    if scan_type not in SCAN_PROFILES:
        scan_type = "detailed"

    if not target:
        return jsonify({"ok": False, "error": "Lutfen hedef IP veya ag araligi girin."}), 400

    try:
        port_spec = normalize_port_spec(port_scope, request.form.get("port_spec", ""))
    except ValueError as validation_error:
        return jsonify({"ok": False, "error": str(validation_error)}), 400

    job = _create_job(target, team_mode, scan_type, nse_scripts, port_scope, port_spec)
    worker = threading.Thread(
        target=_run_scan_job,
        args=(job["id"], target, team_mode, scan_type, nse_scripts, port_scope, port_spec),
        daemon=True,
    )
    worker.start()
    return jsonify({"ok": True, "job_id": job["id"]})


@app.route("/scan-cancel/<job_id>", methods=["POST"])
def cancel_scan(job_id):
    job = _get_job(job_id)
    if job is None:
        return jsonify({"ok": False, "error": "Tarama oturumu bulunamadi."}), 404

    if job.get("status") in {"completed", "failed", "canceled"}:
        return jsonify({"ok": False, "error": "Bu tarama artik iptal edilemez."}), 400

    _update_job(job_id, cancel_requested=True, message="Iptal istegi alindi, tarama durduruluyor.")
    _stop_job_process(job_id)
    return jsonify({"ok": True})


@app.route("/scan-status/<job_id>")
def scan_status(job_id):
    job = _get_job(job_id)
    if job is None:
        return jsonify({"ok": False, "error": "Tarama oturumu bulunamadi."}), 404

    response = jsonify(
        {
            "ok": True,
            "job_id": job["id"],
            "target": job["target"],
            "team_mode": job["team_mode"],
            "scan_type": job.get("scan_type", "detailed"),
            "scan_label": job.get("scan_label", get_scan_label("detailed")),
            "port_scope": job.get("port_scope", "default"),
            "port_spec": job.get("port_spec", ""),
            "port_label": job.get("port_label", "Varsayilan Portlar"),
            "nse_scripts": job.get("nse_scripts", []),
            "nse_script_labels": job.get("nse_script_labels", []),
            "status": job["status"],
            "progress": job["progress"],
            "message": job["message"],
            "error": job["error"],
            "current_step": job.get("current_step"),
            "logs": job.get("logs", []),
            "result_url": f"/?job={job['id']}" if job["status"] == "completed" else None,
        }
    )
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


@app.route("/report")
def download_report():
    return send_file(HTML_RAPOR_DOSYASI)


@app.route("/report/txt")
def download_text_report():
    return send_file(TXT_RAPOR_DOSYASI, mimetype="text/plain; charset=utf-8")


@app.route("/report/pdf")
def printable_report():
    if can_generate_pdf() and os.path.exists(PDF_RAPOR_DOSYASI):
        return send_file(
            PDF_RAPOR_DOSYASI,
            mimetype="application/pdf",
            as_attachment=True,
            download_name="report.pdf",
        )

    html = build_printable_report_html()
    if html is None:
        return Response("PDF icin once bir rapor olusturun.", status=404, mimetype="text/plain; charset=utf-8")
    return Response(html, mimetype="text/html; charset=utf-8")


if __name__ == "__main__":
    os.makedirs(os.path.join(app.root_path, "static"), exist_ok=True)
    init_history_db()
    # Tarama sonrasi uretilen rapor/gorsel dosyalari Flask reloader'ini tetikleyip
    # gelistirme sunucusunun yeniden baslamasina neden olabiliyor.
    app.run(debug=True, use_reloader=False)
